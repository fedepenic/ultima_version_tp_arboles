#include <iostream>
#include <stdlib.h>
#include "menu.h"

//Al ejecutar el programa la linea de ejecucion que se debera escribir sera:
//   ./"nombre_ejecutable" clientes.txt

int main(int argc, char const *argv[]){

	system("clear");
	
	Menu menu_principal;
	menu_principal.iniciar_interfaz(argv[1]);

	return 0;
}