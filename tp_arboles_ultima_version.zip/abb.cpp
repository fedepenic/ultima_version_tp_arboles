#include "abb.h"

Abb::Abb(){
	raiz = NULL;
	cantidad = 0;
}

Nodo_abb* Abb::obtener_raiz(){
	return raiz;
}

Nodo_abb* Abb::buscar_padre(Nodo_abb* nodo,int numero_de_telefono){ 
	if(nodo->obtener_numero_de_telefono() == numero_de_telefono) return nodo;
	if(nodo->obtener_numero_de_telefono() > numero_de_telefono){
		Nodo_abb* nodo_izq = nodo->obtener_izquierda();
		if(nodo_izq){
			if(nodo_izq->obtener_numero_de_telefono() == numero_de_telefono){
				return nodo;
			}
			
			return buscar_padre(nodo_izq,numero_de_telefono);
			
		}
		return nodo;
	}
	else{
		Nodo_abb* nodo_der = nodo->obtener_derecha();
		if(nodo_der){
			if(nodo_der->obtener_numero_de_telefono() == numero_de_telefono){
				return nodo;
			}
			
			return buscar_padre(nodo_der,numero_de_telefono);
			
		}
		return nodo;
	}
}


Nodo_abb* Abb::buscar(Nodo_abb* nodo,int numero_de_telefono){
	if(nodo == NULL) return NULL;
	if(nodo->obtener_numero_de_telefono() == numero_de_telefono){
		return nodo;
	}
	if(nodo->obtener_numero_de_telefono() > numero_de_telefono){
		return buscar(nodo->obtener_izquierda(),numero_de_telefono);
	}

	return buscar(nodo->obtener_derecha(),numero_de_telefono);
}

Nodo_abb* Abb::buscar_nodo(int numero_de_telefono){
	return buscar(raiz,numero_de_telefono);
}


void Abb::agregar_nodo(int numero_de_telefono,Cliente* d){
	Nodo_abb* nuevo_nodo = new Nodo_abb(numero_de_telefono,d);
	if(cantidad == 0) {
		raiz = nuevo_nodo;
		cantidad++;
	}
	else{
			Nodo_abb* padre = buscar_padre(raiz,numero_de_telefono);
			if(padre->obtener_numero_de_telefono() > numero_de_telefono){
				padre->cambiar_izquierda(nuevo_nodo);
			}
			else padre->cambiar_derecha(nuevo_nodo);
			cantidad++;
		}
}

void Abb::swap(Nodo_abb* nodo1,Nodo_abb* nodo2){
	Cliente* aux = nodo1->obtener_dato();
	int numero_de_telefono = nodo1->obtener_numero_de_telefono();
	nodo1->cambiar_dato(nodo2->obtener_dato());
	nodo1->cambiar_numero_de_telefono(nodo2->obtener_numero_de_telefono());
	nodo2->cambiar_dato(aux);
	nodo2->cambiar_numero_de_telefono(numero_de_telefono);
}

void Abb::tipo_de_nodo(Nodo_abb* nodo){
	Nodo_abb* padre = buscar_padre(raiz,nodo->obtener_numero_de_telefono());
	if(!nodo->obtener_derecha() && !nodo->obtener_izquierda()){
		eliminar_nodo_hoja(padre,nodo);
	}
	else{
		if(!nodo->obtener_derecha() || !nodo->obtener_izquierda()){
			eliminar_nodo_con_un_hijo(padre,nodo);
		}
		else eliminar_nodo_con_dos_hijos(nodo);
	}
}

void Abb::eliminar_nodo_hoja(Nodo_abb*padre,Nodo_abb* nodo){	
	if(padre->obtener_numero_de_telefono() == nodo->obtener_numero_de_telefono()) raiz = NULL;
	if(padre->obtener_numero_de_telefono() > nodo->obtener_numero_de_telefono()){
		padre->cambiar_izquierda(NULL);
	}
	else padre->cambiar_derecha(NULL);
	delete nodo;
	cantidad--;
	
}

void  Abb::eliminar_nodo_con_un_hijo(Nodo_abb* padre,Nodo_abb* nodo){
	Nodo_abb* aux = nodo;
	if(nodo->obtener_izquierda()) aux = nodo->obtener_izquierda();
	else aux = nodo->obtener_derecha();
	if(nodo->obtener_numero_de_telefono() == padre->obtener_numero_de_telefono()) raiz = aux;
	if(nodo->obtener_numero_de_telefono() < padre->obtener_numero_de_telefono())	padre->cambiar_izquierda(aux);
	else padre->cambiar_derecha(aux);

	delete nodo;
	cantidad--;
}

Nodo_abb* Abb::buscar_nodo_derecho_minimo(Nodo_abb* nodo){
	if(!nodo->obtener_izquierda()) return nodo;
	return buscar_nodo_derecho_minimo(nodo->obtener_izquierda());
}

void Abb::eliminar_nodo_con_dos_hijos(Nodo_abb* nodo){
	Nodo_abb* aux = buscar_nodo_derecho_minimo(nodo->obtener_derecha());
	Nodo_abb* padre = buscar_padre(raiz,aux->obtener_numero_de_telefono());
	swap(nodo,aux);
	if(nodo->obtener_derecha()->obtener_numero_de_telefono() == aux->obtener_numero_de_telefono()){
		if(aux->obtener_derecha()) nodo->cambiar_derecha(aux->obtener_derecha());
		else nodo->cambiar_derecha(NULL);
		delete aux;
		cantidad--;
	}
	else{
		if(!aux->obtener_derecha() && !aux->obtener_izquierda()){
			eliminar_nodo_hoja(padre,aux);
		}
		else eliminar_nodo_con_un_hijo(padre,aux);
	} 
}

bool Abb::eliminar_nodo(int numero_de_telefono){
	Nodo_abb* nodo_a_eliminar = buscar_nodo(numero_de_telefono);
	if(!nodo_a_eliminar) return false;
	tipo_de_nodo(nodo_a_eliminar);
	return true;
}

void Abb::pos_orden(Nodo_abb* nodo){
	if(!nodo) return;
	pos_orden(nodo->obtener_izquierda());
	pos_orden(nodo->obtener_derecha());
	Nodo_abb* padre = buscar_padre(raiz,nodo->obtener_numero_de_telefono());
	eliminar_nodo_hoja(padre,nodo);
	
	
}

Abb::~Abb(){
	pos_orden(raiz);
}
