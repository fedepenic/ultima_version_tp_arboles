#ifndef INDIVIDUO_H
#define INDIVIDUO_H

#include "cliente.h"
const float DESCUENTO_IND = 0.9;

class Individuo:public Cliente{

	public:

			string nombre;
	
	public:
	
		//PRE: Recibe una cadena de caracteres con el nombre del individuo.
		//COMENTARIO: inicializa el constructor del padre  con descuento_ind
		Individuo(string nombre);

		//COMENTARIO: muestra por pantalla el nombre del individuo
		void listar_cliente();

		void calcular_descuento();

	
};

#endif