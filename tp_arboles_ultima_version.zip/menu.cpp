#include "menu.h"
#include <stdlib.h>

Menu::Menu(){
	arbol = Abb();
	precio_fijo = 0;
}

void Menu::guardar_dato_en_arbol(string linea){
	Lista* lista = new Lista();
	size_t pos_ini = 0;
	string nombre;
	size_t pos = linea.find(',');
 	string numero_de_telefono_aux = linea.substr(pos_ini,pos);
 	int numero_de_telefono = atoi(numero_de_telefono_aux.c_str()); 	
 	while(pos != string::npos){
 		pos_ini = pos;
 		pos = linea.find(',',pos+1);
 		nombre = linea.substr(pos_ini+1,pos-(pos_ini+1));
 		lista->agregar(nombre,lista->tamanio()+1); 				
 	}
 	if(lista->tamanio() > 1){
 		Familia* familia = new Familia(lista);
 		familia->calcular_descuento();
 		arbol.agregar_nodo(numero_de_telefono,familia);
 	}
 	else {
 		delete lista;
 		Individuo* individuo = new Individuo(nombre);
 		individuo->calcular_descuento();
 		arbol.agregar_nodo(numero_de_telefono,individuo);
 	}
}

void Menu::leer_archivo(char const* archivo){
	string linea;
	ifstream archivo_clientes(archivo);
    while(getline(archivo_clientes,linea)){
    	guardar_dato_en_arbol(linea);
    }
    archivo_clientes.close();
}


void Menu::dar_de_baja(){
	int numero_de_telefono;

	cout << "ingrese el numero de telefono a dar de baja:" << endl;
	cin >> numero_de_telefono;


	bool se_dio_de_baja = arbol.eliminar_nodo(numero_de_telefono);
	if(se_dio_de_baja){
		cout << "el cliente se dio de baja correctamente" << endl;
	}
	else {
		cout << "el  numero de telefono no se encuentra vinculado a un cliente" << endl;
	}

}

void Menu::mostrar(Nodo_abb* nodo){
	cout << nodo->obtener_numero_de_telefono() <<" ";
	nodo->obtener_dato()->listar_cliente();

}

void Menu::in_orden(Nodo_abb* nodo){
	if(!nodo){
		return;
	}
	in_orden(nodo->obtener_izquierda());
	mostrar(nodo);
	cout<<"Y el monto que debe abonar por el producto es $";
	cout<<calcular_precio_final(nodo)<<endl<<endl;
	in_orden(nodo->obtener_derecha());
}

void Menu::listar_clientes(){
	in_orden(arbol.obtener_raiz());
}

void Menu::buscar_cliente(){
	int numero_de_telefono;
	cout << "ingrese el numero de telefono del cliente a buscar:" << endl;
	cin >> numero_de_telefono;

	Nodo_abb* nodo = arbol.buscar_nodo(numero_de_telefono);
	if(!nodo) cout << "el numero telefonico ingresado no se encuentra vinculado a un cliente" << endl;
	else {
		cout << "el cliente asociado al numero de telefono ingresado es:" << endl;
		mostrar(nodo);
		cout<<"Y el monto que debe abonar por el producto es $";
		cout<< calcular_precio_final(nodo) << endl;
	}
}

int Menu::generar_numero_de_telefono(){
	int numero_de_telefono = 10030000;
	bool no_encontrado = true;
	while(no_encontrado){
		if(arbol.buscar_nodo(numero_de_telefono)){
			numero_de_telefono ++;
		}
		else no_encontrado = false;	
	}
	return numero_de_telefono;
	
}

void Menu::agregar_familia(int numero_de_telefono){
	Lista* lista = new Lista();
	char continuar;
	string nombre;
	do{
		cout << "ingrese el nombre del nuevo cliente:";
		getline(cin,nombre);
		getline(std::cin,nombre);
		cout << endl;

		cout << "va incorporar mas nombres,SI(s) o NO(n)" << endl;
		cin >> continuar;
		lista->agregar(nombre,lista->tamanio()+1);
	}while(continuar == 's');

	Familia* familia = new Familia(lista);
	familia->calcular_descuento();
	Cliente* cliente = familia;
	arbol.agregar_nodo(numero_de_telefono,cliente);
}

void Menu::agregar_nuevo_cliente(){
	int numero_de_telefono = generar_numero_de_telefono();
	int tipo;
	string nombre;
	cout << "que tipo de cliente va ingresar?:"<< endl;
	cout << "INDIVIDUO.....................[1]"<< endl;
	cout << "FAMILIA.......................[2]"<< endl;
	cin >> tipo;
	if(tipo == 2) agregar_familia(numero_de_telefono);
	else{
		cout << "ingrese el nombre del cliente:";
		getline(cin,nombre);
		getline(cin,nombre);
		cout << endl;
		Individuo* individuo = new Individuo(nombre);
		individuo->calcular_descuento();
		Cliente* cliente = individuo;
		arbol.agregar_nodo(numero_de_telefono,cliente);
	}
}

float Menu::calcular_precio_final(Nodo_abb* nodo){
	Cliente* cliente = nodo->obtener_dato();
	float precio_final = precio_fijo*cliente->obtener_descuento();

	return precio_final;
}

void Menu::indicar_precio_fijo(){
	cout<<endl<<"Por favor indique el precio fijo que tendrán los productos de todos los clientes: "<<endl;
	cin>>precio_fijo;
}

void  Menu::ejecutar_opcion( int opcion) {

	switch(opcion){
			case 1:
				agregar_nuevo_cliente();
			break;

			case 2:
				dar_de_baja();
			break;

			case 3:
				listar_clientes();
			break;

			case 4:
				buscar_cliente();
			break;

			case 5:
				indicar_precio_fijo();
			break;

			default:
				cout << "saliendo..." << endl;
		}
}



void Menu::iniciar_interfaz(char const* archivo){
	leer_archivo(archivo);
	int opcion;
	do{
		
		cout <<"*"<<" **********************************" <<"*"<< endl;
		cout <<"*"<<"           MENU DE OPCIONES        " <<"*"<< endl;
		cout <<"*"<<" Agregar un Nuevo Cliente       [1]" <<"*"<< endl;
		cout <<"*"<<" Dar de Baja un Cliente         [2]" <<"*"<< endl;
		cout <<"*"<<" Listar Clientes                [3]" <<"*"<< endl;
		cout <<"*"<<" Buscar un cliente              [4]" <<"*"<< endl;
		cout <<"*"<<" Indicar el precio fijo         [5]" <<"*"<< endl;
		cout <<"*"<<" Salir                          [6]" <<"*"<< endl;
		cout <<"*"<<"                                   " <<"*"<< endl;
		cout <<"*"<<"  Elija una de las Opciones:       " <<"*"<< endl;
		cout <<"*"<<" **********************************" <<"*"<< endl;

		cin >> opcion;

		ejecutar_opcion(opcion);

	}while(opcion != 6);	
}