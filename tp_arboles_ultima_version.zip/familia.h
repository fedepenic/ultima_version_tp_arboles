#ifndef FAMILIA_H
#define FAMILIA_H

#include "cliente.h"

const float DESCUENTO_FAM = 0.65;

class Familia: public Cliente{

	private:

		Lista* miembros;

	public:

		//PRE: Recibe una lista con los integrantes de la familia a formar.
		//COMENTARIO:inicializa el constructor de la clase padre CLIENTE,   
		Familia(Lista* miembros);

		//COMENTARIO: muestra por pantalla los nombres de sus miembros
		void listar_cliente();

		void calcular_descuento();

		//COMENTARIO: destructor del objeto familia, elima la lista de miembros
		~Familia();


	
};

#endif