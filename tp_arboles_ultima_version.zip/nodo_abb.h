#ifndef NODO_ABB_H
#define NODO_ABB_H

#include "cliente.h"

class Nodo_abb{

	private:

		int numero_de_telefono;	
		Cliente* dato;
		Nodo_abb* derecha;
		Nodo_abb* izquierda;

	public:

		//PRE: numero_de_telefono es un entero y d es de tipo cliente creado con anterioridad
		//COMENTARIO: inicializa los atributos numero_de_telefono y dato con los datos ingresados en el parámetro
		//			los atributos derecha e izquierda los inicializa en NULL
		Nodo_abb(int numero_de_telefono,Cliente* d);

		//PRE:cambia el atributo dato por d, ambos son del mismo tipo de dato
		void cambiar_dato(Cliente* d);

		//PRE: cambia el atributo numero_de_telefono por nueva numero de telefono, ambos son enteros.
		void cambiar_numero_de_telefono(int nuevo_numero_de_telefono);

		//PRE: "der" es un puntero a un Nodo_abb , cambia el atributo "derecha" por "der"
		void cambiar_derecha(Nodo_abb* der);

		//PRE: "izq" es un puntero a un Nodo_abb , cambia el atributo "izquierda" por "izq"
		void cambiar_izquierda(Nodo_abb* izq);

		//POST: devuelve el atributo "dato"
		Cliente* obtener_dato();

		//POST: devuelve el atributo "numero_de_telefono"
		int  obtener_numero_de_telefono();

		//POST: devuelve el atributo "derecha"
		Nodo_abb* obtener_derecha();

		//POST: devuelve el atributo "izquierda"
		Nodo_abb* obtener_izquierda();

		//COMENTARIO: destructor ,libera la memoria del atributo "dato"
		~Nodo_abb();
	
};


#endif