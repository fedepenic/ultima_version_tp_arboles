#include "individuo.h"
#include <iostream>
using namespace std;

Individuo::Individuo(string nombre):Cliente(){
	this->nombre = nombre;
}

void Individuo::listar_cliente(){
	cout << nombre << endl;
}

void Individuo::calcular_descuento(){
	asignar_descuento(DESCUENTO_IND);
}
