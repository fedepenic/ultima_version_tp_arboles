#include "familia.h"
#include <iostream>
using namespace std;


Familia::Familia(Lista* miembros):Cliente(){
	this->miembros = miembros;
}

void Familia::listar_cliente(){
	
	for (int i = 1; i <= miembros->tamanio(); ++i){
		cout << miembros->consultar(i);
		if(i != miembros->tamanio()) cout << ",";
	}
	cout << endl;
}

void Familia::calcular_descuento(){
	asignar_descuento(DESCUENTO_FAM * miembros->tamanio());
}

Familia::~Familia(){
	delete miembros;
}
